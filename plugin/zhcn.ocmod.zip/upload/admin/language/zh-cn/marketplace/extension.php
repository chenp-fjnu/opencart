<?php
// Heading
$_['heading_title'] = '扩展功能';

// Text
$_['text_success']  = '成功: 已修改扩展功能!';
$_['text_list']     = '扩展功能列表';
$_['text_type']     = '选择扩展功能类型进行筛选';
$_['text_filter']   = '筛选';