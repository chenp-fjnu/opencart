<?php
// Heading
$_['heading_title']    = '百度 / 谷歌网站地图';

// Text
$_['text_extension']   = '扩展功能';
$_['text_feed']        = '输出共享';
$_['text_success']     = '成功: 已修改百度 / 谷歌网站地图！';
$_['text_edit']        = '编辑百度 / 谷歌网站地图';

// Entry
$_['entry_status']     = '状态';
$_['entry_data_feed']  = '数据输出共享 Url 链接';

// Error
$_['error_permission'] = '警告: 无权限修改百度 / 谷歌网站地图！';