<?php

// Heading
$_['heading_title'] = '总销售额';

// Text
$_['text_extension']   = '扩展功能';
$_['text_view']     = '查看更多......';