<?php

// Heading
$_['heading_title']     = '最新订单';

// Column
$_['text_extension']   = '扩展功能';
$_['column_order_id']   = '订单 ID';
$_['column_customer']   = '会员';
$_['column_status']     = '状态';
$_['column_total']      = '总计';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '操作';