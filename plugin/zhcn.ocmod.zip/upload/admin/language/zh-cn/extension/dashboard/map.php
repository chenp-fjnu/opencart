<?php

// Heading
$_['heading_title'] = '世界地图';

$_['text_extension']   = '扩展功能';
$_['text_order']    = '订单数量';
$_['text_sale']     = '销售额';