<?php
// Heading
$_['heading_title']     = 'HTML 内容';

// Text
$_['text_extension']   = '扩展功能';
$_['text_module']       = '模组';
$_['text_success']      = '成功: 已修改HTML 内容模组！';
$_['text_edit']         = '编辑 HTML 内容模组';

// Entry
$_['entry_name']        = '模组名称';
$_['entry_title']       = '标题';
$_['entry_description'] = '内容';
$_['entry_status']      = '状态';

// Error
$_['error_permission']  = '警告: 无权限修改 HTML 内容模组！';
$_['error_name']        = '模组名称必须为3-64字符！';