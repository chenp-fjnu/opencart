<?php
// Heading
$_['heading_title'] = '报告';

// Text
$_['text_success']  = '成功: 已修改报告！';
$_['text_list']     = '报告列表';
$_['text_type']     = '选择报告类型';
$_['text_filter']   = '筛选';