<?php
// Text
$_['text_footer']  = '技术支持' . date('Y') . '版权所有';
$_['text_version'] = '版本 2019-09-10';
