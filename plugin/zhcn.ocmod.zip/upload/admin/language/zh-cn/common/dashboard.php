<?php
// Heading
$_['heading_title']                = '仪表盘';

// Error
$_['error_install']                = '警告: 安装目录未删除，为安全起见，请删除安装目录！';