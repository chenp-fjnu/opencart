<?php
// Heading
$_['heading_title']	   = '错误日志';

// Text
$_['text_success']	   = '成功: 已清除错误日志！';
$_['text_list']        = '错误列表';

// Error
$_['error_warning']	   = '警告: 错误日志文件 %s 是 %s!';
$_['error_permission'] = '警告: 无权限清除错误日志！';