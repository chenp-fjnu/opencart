<?php
// Text
$_['text_subject']      = '%s - 订单更新 %s';
$_['text_order_id']     = '订单号 ID:';
$_['text_date_added']   = '添加日期:';
$_['text_order_status'] = '订单状态已被更新为如下状态:';
$_['text_comment']      = '订单备注信息:';
$_['text_link']         = '如查看订单详情，请点击如下链接:';
$_['text_footer']       = '如有问题，请回复本电邮。';