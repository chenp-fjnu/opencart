<?php
// Text
$_['text_subject']  = '%s - 重置密码请求';
$_['text_greeting'] = '新密码被会员账户 %s 所请求。';
$_['text_change']   = '若要重置您的密码，请点击如下链接：';
$_['text_ip']       = '发起该重置请求的IP地址为：';

