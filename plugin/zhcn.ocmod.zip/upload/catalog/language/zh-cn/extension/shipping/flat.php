<?php
// Text
$_['text_title']       = '固定运费';
$_['text_description'] = '固定运费率';