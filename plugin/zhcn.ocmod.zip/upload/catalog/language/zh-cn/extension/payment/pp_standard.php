<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= '警告: 支付接口目前为沙盒测试模式。您的帐户将不会被收取费用。';
$_['text_total']	= '配送费, 手续费, 折扣 & 税';