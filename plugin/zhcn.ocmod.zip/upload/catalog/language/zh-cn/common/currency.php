<?php
// Text
$_['text_currency'] = '货币';