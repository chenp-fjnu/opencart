<?php
// Text
$_['text_success'] = '成功: API 会话成功开启！';

// Error
$_['error_key']  = '警告: 错误的接口 Key!';
$_['error_ip']   = '警告: 您的 IP %s 不允许访问此接口！';
